# Instructions for Codex — Graph-Driven Development v0.1

You are working in an **experimental graph-first software development repository**, not an official Graphify project.

## Source of truth

1. Read `README.md`, `SPEC.md`, `AGENT_CONTRACT.md`, and `concert.gdd.yaml` before changing project architecture or behavior.
2. Treat graph node/rule/scenario IDs as stable references.
3. Treat prose `guards`, `effects`, `statement`, and scenarios as **human-reviewed requirements**, not executable expressions or proof.
4. Never silently change the intent graph or weaken tests to accommodate implementation. Propose spec changes explicitly.

## Initial commands

```bash
python -m pip install -r requirements.txt
python check_spec.py concert.gdd.yaml
python -m unittest -v test_check_spec.py
```

## Work approach

- Start with a small vertical slice: `action.reserve`, `rule.capacity`, `rule.idempotency`, and relevant scenarios.
- Before implementation, propose the technology choice and DB transaction strategy; document consequential choices as a concise ADR under `docs/adr/`.
- Use real authentication boundaries and transactional database tests; do not pretend in-memory test doubles prove concurrency correctness.
- Keep the `component.api` -> `component.storage` direct-import boundary forbidden.
- Do not overbuild: no payment, ticket issuance, microservices, or elaborate UI in the first slice.
- Report exact commands, results, changes, evidence paths, assumptions, and all UNKNOWN items.
- A structural PASS is never a behavioral PASS.

## Completion report

Include: (1) summary, (2) graph IDs affected, (3) tests run with outcomes, (4) negative controls, (5) unresolved UNKNOWN checks, (6) proposed spec changes, if any.
