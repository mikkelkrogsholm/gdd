# Contract for a GDD Implementation Agent

This is a proposed working agreement, not an installed tool or existing integration.

## Inputs

Read the exact specification revision, scoped graph nodes and edges, global invariants, code bindings, test scenarios, and acceptance evidence required. Surface unresolved choices instead of making hidden assumptions.

## Authority and boundaries

Implement only the approved vertical slice and necessary helpers. Preserve stable graph IDs. Update code bindings when files or symbols move. Propose, but do not silently apply, changes that weaken the contract. Never remove negative tests or modify expected results solely to get PASS.

## Implementation

Start from successful cases, failures, and concurrency cases. Build the smallest feature from external entry point through domain behavior to persistence. For concurrency, use the actual database's transaction and isolation behavior. For authorization, test different authenticated identities. For idempotency, test retries before and after state transitions.

## Deliverables

Provide changed code and bindings, affected graph IDs, executed commands and exit statuses, versioned evidence, remaining UNKNOWN checks, and separate suggested spec amendments. A test name or comment is not evidence that a test passed.

## Review

The accepted requirements and crucial assertions need independent review. A second AI agent alone does not establish correctness. Inject at least one deliberate forbidden dependency or business rule defect as a negative control and demonstrate detection.
