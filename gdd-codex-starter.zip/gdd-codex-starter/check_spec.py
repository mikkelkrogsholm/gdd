#!/usr/bin/env python3
"""Small GDD draft linter: checks selected structural properties only.

Does NOT execute guards/effects, test application code, infer semantics,
connect to Graphify, or establish architecture conformance.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:
    raise SystemExit("Missing PyYAML. Run: python -m pip install -r requirements.txt")


class UniqueKeyLoader(yaml.SafeLoader):
    """Reject duplicate YAML mapping keys rather than silently overwriting."""


def unique_mapping(loader: UniqueKeyLoader, node: Any, deep: bool = False) -> dict:
    result: dict = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        try:
            if key in result:
                raise ValueError(f"Duplicate YAML key: {key!r}")
            result[key] = loader.construct_object(value_node, deep=deep)
        except TypeError as exc:
            raise ValueError("Mapping keys must be scalar values") from exc
    return result


UniqueKeyLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique_mapping
)


def validate(doc: dict[str, Any]) -> list[str]:
    """Return selected structural errors; successful validation is not a proof."""
    errors: list[str] = []
    if not isinstance(doc, dict):
        return ["The document must be a mapping"]
    if doc.get("format") != "gdd/0.1":
        errors.append("Unsupported or missing format; expected gdd/0.1")
    registries: dict[str, dict] = {}
    for name in ("nodes", "machines", "rules", "scenarios"):
        value = doc.get(name)
        if not isinstance(value, dict) or not value:
            errors.append(f"{name}: expected a nonempty mapping")
            value = {}
        registries[name] = value
    if errors:
        return errors
    nodes, machines, rules, scenarios = (registries[n] for n in registries)
    ids: set[str] = set()

    def register(item_id: Any, where: str) -> None:
        if not isinstance(item_id, str) or not item_id:
            errors.append(f"{where}: id must be a nonempty string")
        elif item_id in ids:
            errors.append(f"Duplicate graph id: {item_id}")
        else:
            ids.add(item_id)

    for name, registry in registries.items():
        for item_id, value in registry.items():
            register(item_id, name)
            if not isinstance(value, dict):
                errors.append(f"{item_id}: expected a mapping")
    if errors:
        return errors

    def node_ref(value: Any, expected_kind: str | None, where: str) -> None:
        if not isinstance(value, str) or value not in nodes:
            errors.append(f"{where}: unresolved node reference {value!r}")
        elif expected_kind and nodes[value].get("kind") != expected_kind:
            errors.append(f"{where}: expected {expected_kind}, got {value}")

    for item_id, item in nodes.items():
        kind = item.get("kind")
        if kind not in {"component", "entity", "action"}:
            errors.append(f"{item_id}: unsupported kind {kind!r}")
        if not item.get("description"):
            errors.append(f"{item_id}: missing description")
        if kind in {"entity", "action"}:
            node_ref(item.get("owner"), "component", item_id + ".owner")
        if kind == "entity":
            node_ref(item.get("stored_in"), "component", item_id + ".stored_in")
        if kind == "action":
            for field in ("input", "context", "returns", "errors", "specification"):
                if field not in item:
                    errors.append(f"{item_id}: missing {field}")

    edges = doc.get("edges", [])
    if not isinstance(edges, list):
        errors.append("edges must be a list")
        edges = []
    for i, edge in enumerate(edges):
        if not isinstance(edge, dict):
            errors.append(f"edge {i}: expected mapping")
            continue
        register(edge.get("id"), f"edge {i}")
        relation = edge.get("relation")
        if relation not in {"imports", "calls"}:
            errors.append(f"edge {i}: unsupported relation {relation!r}")
        node_ref(edge.get("from"), "component", f"edge {i}.from")
        node_ref(edge.get("to"), "action" if relation == "calls" else "component", f"edge {i}.to")

    for mid, machine in machines.items():
        node_ref(machine.get("entity"), "entity", mid + ".entity")
        states = machine.get("states", [])
        if not isinstance(states, list) or not states or not all(isinstance(s, str) for s in states):
            errors.append(f"{mid}: states must be a nonempty string list")
            continue
        if len(set(states)) != len(states):
            errors.append(f"{mid}: duplicate states")
        if machine.get("initial") not in states:
            errors.append(f"{mid}: initial state not declared")
        terminal = machine.get("terminal", [])
        if not isinstance(terminal, list) or any(s not in states for s in terminal):
            errors.append(f"{mid}: invalid terminal states")
            terminal = []
        transitions = machine.get("transitions", [])
        if not isinstance(transitions, list):
            errors.append(f"{mid}: transitions must be a list")
            continue
        seen: set[tuple[str, str]] = set()
        for trans in transitions:
            if not isinstance(trans, dict):
                errors.append(f"{mid}: transition must be a mapping")
                continue
            tid = trans.get("id")
            register(tid, mid)
            for end in ("from", "to"):
                if trans.get(end) not in states:
                    errors.append(f"{tid}: undeclared {end} state")
            if trans.get("from") in terminal:
                errors.append(f"{tid}: mutation from terminal state")
            node_ref(trans.get("trigger"), "action", f"{tid}.trigger")
            pair = (str(trans.get("from")), str(trans.get("trigger")))
            if pair in seen:
                errors.append(f"{tid}: multiple transitions for same state/trigger; unsupported in this draft")
            seen.add(pair)
            for field in ("guard", "effects"):
                if not isinstance(trans.get(field), str) or not trans[field]:
                    errors.append(f"{tid}: missing textual {field}")

    coverage: set[str] = set()
    for sid, scenario in scenarios.items():
        for field in ("given", "when", "then"):
            if not isinstance(scenario.get(field), str) or not scenario[field]:
                errors.append(f"{sid}: missing textual {field}")
        for rid in scenario.get("verifies", []):
            if rid not in rules:
                errors.append(f"{sid}: unresolved rule {rid!r}")
            else:
                coverage.add(rid)
        for aid in scenario.get("actions", []):
            node_ref(aid, "action", sid + ".actions")
    for rid, rule in rules.items():
        for target in rule.get("targets", []):
            if target not in ids:
                errors.append(f"{rid}: unresolved target {target!r}")
        if not rule.get("statement") or not rule.get("verification"):
            errors.append(f"{rid}: missing statement or verification method")
        if rule.get("blocking") and rid not in coverage:
            errors.append(f"{rid}: no PLANNED verification scenario")
        constraint = rule.get("constraint")
        if constraint:
            node_ref(constraint.get("from"), "component", rid + ".constraint.from")
            node_ref(constraint.get("to"), "component", rid + ".constraint.to")
    for bid in doc.get("bindings", {}):
        node_ref(bid, "component", "bindings")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("spec", type=Path)
    args = parser.parse_args()
    try:
        document = yaml.load(args.spec.read_text(encoding="utf-8"), Loader=UniqueKeyLoader)
        errors = validate(document)
    except (OSError, ValueError, TypeError, KeyError, AttributeError, yaml.YAMLError) as exc:
        print(f"Invalid specification: {exc}", file=sys.stderr)
        return 2
    print(json.dumps({
        "spec_structure": "FAIL" if errors else "PASS",
        "scope": "selected structural checks only; not a complete language validator",
        "application_behavior": "UNKNOWN",
        "architecture_conformance": "UNKNOWN",
        "errors": errors,
    }, indent=2, ensure_ascii=False))
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
