"""Tests of the structural draft linter — NOT of application behavior."""
import copy
import unittest
from pathlib import Path

import yaml
from check_spec import UniqueKeyLoader, validate


class SpecLinterTests(unittest.TestCase):
    def setUp(self):
        self.doc = yaml.load(
            Path(__file__).with_name("concert.gdd.yaml").read_text(encoding="utf-8"),
            Loader=UniqueKeyLoader,
        )

    def test_example_is_structurally_valid(self):
        self.assertEqual(validate(self.doc), [])

    def test_unknown_edge_endpoint_is_rejected(self):
        self.doc["edges"][0]["to"] = "component.missing"
        self.assertTrue(any("unresolved" in e for e in validate(self.doc)))

    def test_wrong_owner_type_is_rejected(self):
        self.doc["nodes"]["action.reserve"]["owner"] = "entity.concert"
        self.assertTrue(any("expected component" in e for e in validate(self.doc)))

    def test_unknown_state_is_rejected(self):
        self.doc["machines"]["machine.reservation"]["transitions"][0]["to"] = "paid"
        self.assertTrue(any("undeclared" in e for e in validate(self.doc)))

    def test_terminal_mutation_is_rejected(self):
        self.doc["machines"]["machine.reservation"]["transitions"][1]["from"] = "cancelled"
        self.assertTrue(any("terminal" in e for e in validate(self.doc)))

    def test_ambiguous_transition_pair_is_rejected(self):
        transitions = self.doc["machines"]["machine.reservation"]["transitions"]
        clone = copy.deepcopy(transitions[0])
        clone["id"] = "transition.ambiguous"
        transitions.append(clone)
        self.assertTrue(any("multiple transitions" in e for e in validate(self.doc)))

    def test_missing_planned_rule_check_is_rejected(self):
        del self.doc["scenarios"]["scenario.api_boundary"]
        self.assertTrue(any("no PLANNED" in e for e in validate(self.doc)))

    def test_unknown_scenario_rule_is_rejected(self):
        self.doc["scenarios"]["scenario.reserve"]["verifies"].append("rule.missing")
        self.assertTrue(any("unresolved rule" in e for e in validate(self.doc)))

    def test_graph_ids_are_unique_across_registries(self):
        self.doc["rules"]["action.reserve"] = self.doc["rules"]["rule.capacity"]
        self.assertTrue(any("Duplicate graph id" in e for e in validate(self.doc)))

    def test_duplicate_yaml_keys_are_rejected(self):
        with self.assertRaises(ValueError):
            yaml.load("nodes: {}\nnodes: {}\n", Loader=UniqueKeyLoader)

    def test_unknown_format_is_rejected(self):
        self.doc["format"] = "graphify"
        self.assertTrue(validate(self.doc))

    def test_unknown_binding_is_rejected(self):
        self.doc["bindings"]["component.missing"] = {"paths": ["src/missing/**"]}
        self.assertTrue(any("unresolved node" in e for e in validate(self.doc)))

    def test_missing_action_contract_is_rejected(self):
        del self.doc["nodes"]["action.reserve"]["returns"]
        self.assertTrue(any("missing returns" in e for e in validate(self.doc)))

    def test_prose_is_not_executed_or_semantically_checked(self):
        self.doc["machines"]["machine.reservation"]["transitions"][0]["guard"] = "This could be contradictory; the linter does not know."
        self.assertEqual(validate(self.doc), [])

    def test_nonmapping_document_is_rejected(self):
        self.assertTrue(validate([]))


if __name__ == "__main__":
    unittest.main()
