# Graph-Driven Development (GDD) v0.1 — Methodology

## 1. Definition

**Graph-Driven Development** is a workflow in which a unified **intent graph** describes desired architecture and behavior. Implementations are produced in small vertical slices, and evidence is collected to determine whether they satisfy those contracts.

This is an experimental methodology, not an established standard or a Graphify feature.

Three concepts must remain separate:

- **Intent Graph:** what should exist and what guarantees must hold.
- **Implementation Graph:** structure observed in real source code and runtime systems.
- **Evidence:** concrete, revision-specific checks that support or refute a requirement.

A graph inferred from code does not, by itself, prove business behavior. A rule stated in a document does not prove that the rule is enforced.

## 2. Unified model and views

Use one underlying data model with multiple views, rather than separately maintained diagrams.

**Architecture view:** components, domain entities, ownership, imports, calls, boundaries, and forbidden dependencies.

**Behavior view:** actions, authenticated context, inputs, outputs, errors, state machines, transition guards and effects, invariants, and example scenarios.

A component is not necessarily an entity; one component may own several entities. Graph granularity should capture critical contracts without reproducing every source line.

## 3. Pseudo-graph to contract

Start with an informal readable sketch such as:

```text
project ConcertReservations
architecture:
  API -> Reservations : calls
  Reservations -> Storage : uses
  Reservations owns Concert
  Reservations owns Reservation
  forbid API -> Storage : direct_import
behavior Reservation:
  absent -- ReserveSeat [seat_available] --> reserved
  reserved -- CancelSeat [user_is_owner] --> cancelled
rules:
  active_reservations must not exceed capacity
  repeated requests must not create additional reservations
```

Then make only the next selected vertical slice precise in `concert.gdd.yaml`. Preserve unknowns as open decisions, never silent assumptions.

`gdd/0.1` is a **proposed** YAML representation. Strings such as `guard`, `effects`, and `statement` are prose and **are not executable assertions**. The structural linter cannot validate their truth.

## 4. Workflow

1. **Sketch:** define components, actions, entities, invariants, and open questions.
2. **Contract:** specify a small end-to-end feature, including failure cases, concurrency, authorization, and verification scenarios.
3. **Implement:** give the AI agent a bounded task drawn from graph IDs and their neighboring contracts.
4. **Verify:** run real code checks, unit/integration/authorization/concurrency tests, and negative controls.
5. **Review:** approve changes or explicitly propose a specification revision; do not quietly rewrite requirements to make the implementation pass.

The unit of work is a vertical feature, not an entire graph and not necessarily a single node.

## 5. Critical example behaviors

The reservation example intentionally documents important cases:

- **Idempotency:** keys are scoped to user and action. Same user/key/concert returns the same reservation and its **current** state without additional effects. Same key for another concert conflicts. Look up previous successful requests before checking capacity.
- **Concurrency:** reservation creation, uniqueness, and capacity enforcement must be atomic and behave as if operations were executed in a valid serial order. An unguarded read-then-insert is insufficient.
- **Authorization:** identity comes from trusted server authentication. Only an owner may cancel or retrieve a reservation; missing and unauthorized reservations produce indistinguishable errors.
- **Cancellation:** changing reserved to cancelled frees exactly one seat once. Retrying cancellation has no additional effects. Replaying the old reservation request never reactivates a cancelled record.
- **Atomic failure:** pre-commit faults must leave no partial write or claimed request key.

The `absent` state models an entity before creation; it is not stored. `cancelled` is terminal for mutation but remains readable in authorized retries.

## 6. Graphify integration concept

A future adapter may inspect Graphify's `graphify-out/graph.json` and convert relevant **code-derived** observations into a normalized implementation graph.

Logical nodes require **bindings** to real paths/symbols, e.g. `component.reservations -> src/reservations/**`. Aggregate file/symbol observations into logical component-level relationships.

Compare scoped architectural constraints, **not** raw graph isomorphism. An internal helper function does not always deserve its own intent node; a prohibited cross-component import deserves a violation.

Do not mistake document-extracted statements for verified implementation behavior. Provenance is required: code observations, documentation claims, dynamic tests, and human approvals have different meanings. Missing scans and unmapped nodes yield UNKNOWN, not PASS.

Graphify is a potential observer, not the entire verifier. This repository includes no Graphify adapter yet.

## 7. Verification and evidence

Use targeted checks for different requirement types:

| Requirement | Required check |
| --- | --- |
| API must not import storage directly | Static import scan with resolved bindings and an injected forbidden-import negative control |
| Last seat must not be double-booked | Concurrent integration tests with the actual selected database |
| Retries create no duplicate reservation | Sequential and simultaneous idempotency tests |
| Only owner can cancel | Negative authorization tests across different identities |
| Faults must leave no partial mutation | Persistence fault injection around transaction boundaries |
| State transitions follow contract | Stateful/model-based tests plus explicit example scenarios |

Every check returns **PASS**, **FAIL**, or **UNKNOWN**:

- PASS = a specific test/check ran and passed for a declared scope and revision.
- FAIL = the check detected noncompliance.
- UNKNOWN = absent, inconclusive, stale, unexecuted, or unmapped verification.

For evidence, record the specification revision, code revision, check ID, checker version, scope, result, and raw evidence location. A result must not be silently reused after relevant changes.

Critical requirements marked `blocking: true` cannot be accepted while UNKNOWN under the proposed policy.

## 8. v0.1 exclusions and next experiments

No graphical editor, complete GDD CLI, production language, code generator, database schema, or working reservation service is included. The linter validates only selected structural properties of the YAML model. It does not execute guards and effects, infer behavior, or establish conformance.

**First experiment:** implement a single seat reservation vertical slice with a real database; demonstrate capacity, same-key concurrency, retry idempotency, and failure rollback. Intentionally inject defects and ensure that relevant checks fail. Implement cancellation next. Later create the Graphify adapter and drift report.

## 9. Related foundations

This is not a claim to invent model-driven development. It draws on model-driven architecture, state-machine modeling, specification-based testing, and code-graph extraction. References:

- OMG Model Driven Architecture: https://www.omg.org/mda/
- W3C SCXML: https://www.w3.org/TR/scxml/
- Hypothesis stateful testing: https://hypothesis.readthedocs.io/en/latest/stateful.html
- Graphify: https://github.com/Graphify-Labs/graphify
