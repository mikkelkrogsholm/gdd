# Graph-Driven Development (GDD) — Codex Starter

**Experimental GDD v0.1** — a graph-first workflow for describing both **architecture and behavior**, then verifying code against the specification. This is an independent prototype, **not an official Graphify product**.

## Get started in Codex

1. Unzip this bundle and open its directory as a Codex workspace.
2. Read `AGENTS.md` and `SPEC.md` before editing code.
3. Install Python 3.10+ and dependencies; run the baseline checks:

```bash
python -m pip install -r requirements.txt
python check_spec.py concert.gdd.yaml
python -m unittest -v test_check_spec.py
```

4. Ask Codex: **"Read AGENTS.md and SPEC.md. Implement the smallest vertical slice for `action.reserve` from concert.gdd.yaml, including a real transactional database, contract tests, and an evidence report. Do not weaken the specification; record anything not verified as UNKNOWN."**
5. Review changes and test results before accepting them; then implement cancellation and the remaining scenarios.

## Repository contents

- `AGENTS.md`: persistent Codex working rules and delivery requirements.
- `SPEC.md`: English GDD v0.1 methodology and design decisions.
- `concert.gdd.yaml`: unified intent graph for the reservation domain.
- `AGENT_CONTRACT.md`: implementation and review contract for agents.
- `check_spec.py`: structural linter; **not** a behavioral verifier.
- `test_check_spec.py`: unit tests for the linter.
- `requirements.txt`: PyYAML dependency.
- `prompts/`: ready-to-use Codex prompts for initial work and the future Graphify adapter.
- `evidence/`: baseline check outputs, not product implementation evidence.

## Current scope and limits

This repository does **not** contain a reservation app, a Graphify adapter, a generator, or runtime verification. The graph is an intent specification with pseudocode guards and effects. Graphify-style structural observations cannot by themselves establish business-rule compliance. All real application behavior and architectural conformance start as **UNKNOWN**.

For Codex, begin with a small, independently testable vertical slice rather than asking an agent to implement the entire graph at once.
